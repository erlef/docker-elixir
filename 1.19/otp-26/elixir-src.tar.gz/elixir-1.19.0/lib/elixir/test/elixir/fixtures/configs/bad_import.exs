import Config
import_config "bad_root.exs"
