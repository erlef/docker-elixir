defprotocol Protocol.ConsolidationTest.NoImpl do
  def ok(term)
end
