import Config
config :my_app, :key, :value
