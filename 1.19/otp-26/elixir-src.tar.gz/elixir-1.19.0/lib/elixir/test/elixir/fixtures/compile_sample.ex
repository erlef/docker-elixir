defmodule(CompileSample, do: nil)
